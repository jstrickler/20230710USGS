"""
Module documentation...
"""
def sample_function():
    """
    Sample function documentation...
    """
    print("sample mycoolmodule function")

class Mycoolmodule:
    """
    Class documentation...
    """

    def sample_method(self):
        """
        Sample method documentation...
        """
        print("sample Mycoolmodule instance method")
