from setuptools import setup

# note -- this file is not used when building with pyproject.toml

if __name__ == "__main__":
    setup()

